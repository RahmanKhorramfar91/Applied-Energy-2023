# -*- coding: utf-8 -*-
"""
Created on Fri Jul 15 02:50:12 2022
  
@author: Rahman Khorramfar
"""

# from IPython import get_ipython;
# get_ipython().magic('reset -f') # to clear the namespace
# get_ipython().magic('clear');

import time;
import gurobipy as gp;
from gurobipy import GRB, quicksum,LinExpr;
from Setting import Setting,EV,GV;
import sys; 
#from Modules import Create_Power_System_Model;
#import Modules;
#%% Set Default Setting for the Porblem 
Setting.Power_network_size = 6; 

Setting.rep_day_folder = 'joint_CF_with_extreme_days';#extreme_days
Setting.num_rep_days = 30;
Setting.emis_case = 4;
Setting.electrification_scenario = 'HM';   # currently HM and RM, but can be MM, MS,MR etc.
Setting.emis_reduc_goal = 0.8; # %80
Setting.VRE_share = 0.5;
#Setting.RNG_cap = 0.2;
Setting.solver_gap = 0.01;
Setting.wall_clock_time_lim = 8; #hour
Setting.UC_active = True;
Setting.relax_UC_vars = True;
Setting.relax_int_vars = False;
Setting.solver_thread_num = 4;
Setting.e_shed_penalty = 1e4;
Setting.g_shed_penalty = 1e3;
Setting.Metal_air_storage_cost='low';
Setting.NG_price = 5.45;
Setting.RNG_price=20;
Setting.expansion_allowed = True;


if len(sys.argv)>1:
    print(str(sys.argv));
    Setting.rep_day_folder = sys.argv[1];
    Setting.Power_network_size = int(sys.argv[2]);
    Setting.num_rep_days = int(sys.argv[3]);
    Setting.emis_case = int(sys.argv[4]);
    Setting.electrification_scenario = sys.argv[5];
    Setting.emis_reduc_goal = float(sys.argv[6]); # %80
    Setting.VRE_share = float(sys.argv[7]);
    #Setting.RNG_cap = float(sys.argv[6]);
    Setting.solver_gap = float(sys.argv[8]);
    Setting.wall_clock_time_lim = int(sys.argv[9]); # hour
    Setting.UC_active = bool(int(sys.argv[10]));
    Setting.relax_UC_vars = bool(int(sys.argv[11]));
    Setting.relax_int_vars = bool(int(sys.argv[12]));
    Setting.solver_thread_num = int(sys.argv[13]);
    Setting.Metal_air_storage_cost=sys.argv[14]; # high, low, medium, no-metal-air
    Setting.NG_price = float(sys.argv[15]);
    Setting.RNG_price = float(sys.argv[16]);

Setting.wall_clock_time_lim = Setting.wall_clock_time_lim*3600; # convert to second for Gurobi
Setting.print_result_header = 1;
Setting.copper_plate_approx = False;
Setting.print_all_vars = 0;

s_time = time.time();

#%% create and recall and run the modules
Model = gp.Model();
import Module_NG_FY;
Module_NG_FY.Power_System_Model(Model); # Power System
Module_NG_FY.NG_System_Model(Model);# NG System
Module_NG_FY.Coupling_constraints(Model);# Coupling Constraints

#% add objective function and run
Model.modelSense = GRB.MINIMIZE;
#Model.setObjective(EV.e_system_cost);
if Setting.emis_case==1:
    Model.setObjective(EV.e_system_cost);
else:
    Model.setObjective(GV.g_system_cost+ EV.e_system_cost);
# Model.setParam('OutputFlag', 0);
Model.setParam('MIPGap', Setting.solver_gap);
Model.setParam('Timelimit', Setting.wall_clock_time_lim);
Model.setParam('Threads',Setting.solver_thread_num);

Model.optimize();
print(f"Num of Vars: {Model.NumVars}");
print(f"Num of Int Vars: {Model.NumIntVars}");
print(f"Num of Constraints: {Model.NumConstrs}");
MIP_gap = 100*Model.MIPGap;

#% print
Module_NG_FY.Get_var_vals(Model);
Module_NG_FY.Get_marginal_prices();
Module_NG_FY.Publish_results(s_time,MIP_gap);

print(sys.argv);
print(f"\n\n Elapsed time (seconds): {time.time()-s_time}");
print(f"MIP Gap (%): {MIP_gap}");
# print(f"\n Establishment cost: {format(EV.est_cost_val,'.2E')}");
# print(f"Decommissioning cost: {format(EV.decom_cost_val,'.2E')}");
# print(f"FOM cost: {format(EV.FOM_cost_val,'.2E')}");
# print(f"VOM cost: {format(EV.VOM_cost_val,'.2E')}");
# print(f"Fuel cost: {format(EV.nuc_fuel_cost_val,'.2E')}");
# print(f"Fuel cost: {format(EV.gas_fuel_cost_val,'.2E')}");
# print(f"Startup cost: {format(EV.startup_cost_val,'.2E')}");
# print(f"Sheding cost: {format(EV.shedding_cost_val,'.2E')}");
# print(f"Storage cost: {format(EV.elec_storage_cost_val,'.2E')}");
# print(f"Trans. Est. cost: {format(EV.est_trans_cost_val,'.2E')}");
# print(f"e emission: {format(EV.emis_amount_val,'.2E')}");
# print(f"CCS Cost: {format(EV.CCS_cost_val,'.2E')}");
print(f" Power system cost: {format(EV.e_system_cost_val,'.3E')}\n")

# print(f"\n\n storage inv. cost: {format(GV.inv_str_cost_val,'.2E')}");
# print(f"pipeline inv. cost: {format(GV.inv_pipe_cost_val,'.2E')}");
# print(f"Shedding cost: {format(GV.shed_cost_val,'.2E')}")
# print(f"RNG cost: {format(GV.RNG_cost_val,'.2E')}")
# print(f"FOM storage cost: {format(GV.fom_str_cost_val,'.2E')}")
# print(f"NG import cost: {format(GV.import_cost_val,'.2E')}")
# print(f"NG Emission: {format(GV.emis_amount_val,'.2E')}")
print(f"NG system cost: {format(GV.g_system_cost_val,'.3E')}")
print(f"Total Energy cost: {format(GV.g_system_cost_val+EV.e_system_cost_val,'.3E')}")



