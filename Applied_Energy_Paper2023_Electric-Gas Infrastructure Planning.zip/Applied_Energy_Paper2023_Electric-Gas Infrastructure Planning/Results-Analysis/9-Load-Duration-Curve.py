# -*- coding: utf-8 -*-
"""
Created on Fri Jun 16 16:33:48 2023
@author: Rahman Khorramfar
"""
from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
import networkx as nx;
import os;
case = 4;
scen = 'RM';
emis_case = 0.8;
rep_days = 30;
season = 'Winter';
LDES='no-metal-air';

path = os.getcwd();
p1 = os.path.abspath(os.path.join(path, os.pardir)); #parent path
# p2 = p1+'\\Gas_System_Data\\ng_daily_load2050_'+scen+'.csv';
# dfg = pd.read_csv(p2);

p2 = p1+'\\Power_System_Data\\zonal_load-'+scen+'.csv';
dfp = pd.read_csv(p2);
dfp = dfp.iloc[:,1:]
dfp = dfp.sum(axis=1).to_numpy();
# dfd  = [11, 15, 16, 21, 22, 30, 78, 92, 111, 152, 172, 185, 194, 198, 220, 222, 224, 246, 249, 265, 270, 273, 276, 289, 325, 327, 343, 360, 362, 364];
dfd1 = pd.read_csv(p1+f'/joint_CF_with_extreme_days/joint_CF_with_extreme_days_k={rep_days}.csv')
df2 = dfd1[dfd1['Medoid']==1];
dfd = np.array(df2.index);

# medoid to cluster
med2cl = dict(zip(df2['Cluster'],dfd));


fig, ax = plt.subplots(nrows=2, ncols=1, figsize=(30, 12),
                       gridspec_kw={
                           'width_ratios': [10],
                           'height_ratios': [10,10],
                       'wspace': 0.2,
                       'hspace': 0.4});

ax[0].plot(np.sort(dfp)[::-1],linewidth=8,linestyle='solid',color='xkcd:soft blue',label='Full year')
ax[1].plot(dfp,linewidth=2,linestyle='solid',color='xkcd:soft blue',alpha=0.8,label='Full year');
dfr = np.zeros(len(dfd1)*24);
dfi = np.zeros(len(dfd1)*24);

for i in range(len(dfd1)):
    s0 = dfd1['Cluster'][i];
    s1 = med2cl[s0];
    dfr[i*24:(i+1)*24] = dfp[(s1-1)*24:s1*24];
    
ax[0].plot(np.sort(dfr)[::-1],linewidth=6,linestyle='solid',color='xkcd:deep red',label='Representative days')

dfr = np.zeros(len(dfd)*24);
dfi = np.zeros(len(dfd)*24);
for i,d in enumerate(dfd):
    dfr[i*24:(i+1)*24] = dfp[(d-1)*24:d*24];
    dfi[i*24:(i+1)*24] = np.arange((d-1)*24,d*24);
    if i==0:
        ax[1].plot(np.arange((d-1)*24,d*24),dfp[(d-1)*24:d*24],color='xkcd:deep red',linewidth=5,label='Representative days');
    else:
        ax[1].plot(np.arange((d-1)*24,d*24),dfp[(d-1)*24:d*24],color='xkcd:deep red',linewidth=5);
# ax[0].plot(dfi,np.sort(dfr)[::-1],color='xkcd:deep red',marker='*',markersize=9,linewidth=0,label='Representative days');

for i in range(len(ax)):
    ax[i].set_yticks([6.5e3,7.5e3,10e3,15e3,20e3,25e3,27e3]);
    ax[i].set_yticklabels(['','7.5','10','15','20','25',''],fontsize=16,fontweight='bold')
    ax[i].text(-220,28e3,'GW',fontsize=20,fontweight='bold');
    ax[i].set_xlim([-150,9000])
    ax[i].set_xticks([-10,0,2e3,4e3,6e3,8e3,8760,9e3]);
    ax[i].set_xticklabels(['','0','2000','4000','6000','8000','8760',''],fontsize=16,fontweight='bold');
    ax[i].legend(loc='upper center',ncol=6, bbox_to_anchor=(0.85, 0.95), prop={'size': 20,'weight':'bold'});


ax[0].set_ylabel('Aggregate Power Load',fontsize=20,fontweight='bold');
ax[1].set_ylabel('Aggregate Power Load',fontsize=20,fontweight='bold');


ax[0].text(4400,1000,'(a) Operating Hours',fontsize=20,fontweight='bold');
ax[1].text(4400,1000,'(b) Operating Hours',fontsize=20,fontweight='bold');



name = 'LDC-rep-days.pdf';
fig.savefig(name,bbox_inches='tight');







