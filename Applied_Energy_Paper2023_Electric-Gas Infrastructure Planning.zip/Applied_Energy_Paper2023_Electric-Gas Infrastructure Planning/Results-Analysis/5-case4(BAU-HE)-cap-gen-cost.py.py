# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 15:15:47 2022
Fig. 7
@author: Rahman Khorramfar
"""

from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
# import geopandas as gpd;
# import networkx as nx;
# import os;

df = pd.read_csv('JPoNG_Results2.csv');
df = df.sort_values('reduc-goal');
xi = np.arange(0.8,1,0.05);
scen = ['RM','HM'];
LDES = 'no-metal-air';
df = df[df['Metal-air-cost']==LDES];
df['Gen/Str Inv+FOM'] = df['est-cost']+df['FOM']+df['storage1-cost']+df['storage2-cost'];
df['Pipe/Str Inv+FOM'] = df['inv-storage']+df['FOM-storage']+df['pipe-est-cost'];

fig, ax = plt.subplots(nrows=1, ncols=5, figsize=(24, 12),
                       gridspec_kw={
                           'width_ratios': [10,1,10,1,20],
                           'height_ratios': [5],
                       'wspace': 0.1,
                       'hspace': 0.1});

bw = 0.7;
lbs_est = ['ng.1','solar.1','wind.1','hydro.1','nuclear.1',
       'OCGT.1','CCGT.1','CCGT-CCS.1',
       'solar-UPV.1','wind-new.1','wind-offshore.1','nuclear-new.1'];

lbs_dec = ['ng.2','solar.2','wind.2','hydro.2','nuclear.2',
       'OCGT.2','CCGT.2','CCGT-CCS.2',
       'solar-UPV.2','wind-new.2','wind-offshore.2','nuclear-new.2'];
lbs = ['ng','solar','wind','hydro','nuclear',
       'OCGT','CCGT','CCGT-CCS',
       'solar-UPV','wind-new','wind-offshore','nuclear-new','Li-ion'];

cap = np.array([173,6.3,42,23,933,237,	573,	400,	10,	10,	10,	360]);# nameplate cap for new plants
exis_plant_num = np.array([92,71,24,112,4,0,0,0,0,0,0,0]);
cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','xkcd:melon','xkcd:purpleish'];
order = [4,11,3,0,5,6,7,2,9,10,1,8];
lbs_est = [lbs_est[i] for i in order];
lbs_dec = [lbs_dec[i] for i in order];
cap = [cap[i] for i in order];
exis_plant_num = [exis_plant_num[i] for i in order];
order = [4,11,3,0,5,6,7,2,9,10,1,8,12];
cols =[cols[i] for i in order];
lbs = [lbs[i] for i in order];

aMax = 0;
aMin = 0;
aMinus = np.zeros(len(xi));
aPlus = np.zeros(len(xi));
for i in range(len(lbs_est)):
    if i==1 or i==4 or i==5 or i==7 or i==10: continue;

    #a = np.zeros(len(xi));
    a1 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[0])&(df['Metal-air-cost']=='no-metal-air')];
    a2 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[1])&(df['Metal-air-cost']=='no-metal-air')];
    #a2=100*a1[lbs[i]]/a1['prod-sum'];
    ao1 = np.array(exis_plant_num[i]+a1[lbs_est[i]])-np.array(a1[lbs_dec[i]]);
    ao2 = np.array(exis_plant_num[i]+a2[lbs_est[i]])-np.array(a2[lbs_dec[i]]);
    
    a = (ao2-ao1)*cap[i];
    # print(lbs[i]);
    # print(a);
    aBot = np.zeros(len(xi));
    for i2 in range(len(xi)):
         if a[i2]<=0:
             aBot[i2] = aMinus[i2]; 
             #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
         else:
             aBot[i2] = aPlus[i2];    
    ax[0].bar(np.arange(len(xi)),a,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
    if max(aPlus)>aMax:
        aMax = max(aPlus);
    if min(aMinus)<aMin:
        aMin = min(aMinus);        
    for i2 in range(len(xi)):
        if a[i2]<=0:
            aMinus[i2] += a[i2];
        else:
            aPlus[i2] += a[i2];
a = np.array(a2['total-str1-cap'])-np.array(a1['total-str1-cap']);
for i2 in range(len(xi)):
 if a[i2]<=0:
     aBot[i2] = aMinus[i2]; 
     #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
 else:
     aBot[i2] = aPlus[i2];


ax[0].bar(np.arange(len(xi)),a,width=bw,color = cols[-1],bottom=aBot,label=lbs[-1]);

ax[0].set_xticks([0,0,1,2,3,3.5]);
ax[0].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
ax[0].set_yticks(np.array([-4,-3,0,1,2,3,4,5,6,6.5])*1e3);
ax[0].set_ylim([-4000,6500]);
ax[0].set_yticklabels(['','-3','0','1','2','3','4','5','6',''],fontsize=19,fontweight='bold');

ax[0].legend(loc='upper center',ncol=3, bbox_to_anchor=(1, 1.21), prop={'size': 21});
ax[0].xaxis.set_label_coords(1.1, -0.05);
ax[0].text(1,-6200,'(a)', fontsize=30,fontweight='bold');
ax[0].text(7,-5200,'Emission Reduction Goals (%)',fontsize=20,fontweight='bold');ax[0].text(-0.8,6.6e3,'GW',fontsize=20,fontweight='bold');
ax[0].set_ylabel('Change in Capacity',fontsize=20,fontweight='bold');

#%%
ax[1].axis('off');
bw = 0.7;
lbs = ['ng','solar','wind','hydro','nuclear',
        'OCGT','CCGT','CCGT-CCS',
        'solar-UPV','wind-new','wind-offshore','nuclear-new'];

cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','xkcd:melon'];
order = [4,11,3,0,5,6,7,2,9,10,1,8];
lbs = [lbs[i] for i in order];
cols =[cols[i] for i in order];

aMaxT=0;
aMinT=0;

aMax = 0;
aMin = 0;

aMinus = np.zeros(len(xi));
aPlus = np.zeros(len(xi));
td = np.zeros(len(lbs));

for i in range(len(lbs)):
    if i==1 or i==4 or i==5 or i==7 or i==10: continue;

    #a = np.zeros(len(xi));
    a1 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[0])&(df['Metal-air-cost']=='no-metal-air')];
    a2 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[1])&(df['Metal-air-cost']=='no-metal-air')];
    #a2=100*a1[lbs[i]]/a1['prod-sum'];
    a = np.array(a2[lbs[i]])-np.array(a1[lbs[i]]);
    td[i] += sum(a);
    # print(f"type {lbs[i]}, diff: {a}")
    aBot = np.zeros(len(xi));
    for i2 in range(len(xi)):
          if a[i2]<=0:
              aBot[i2] = aMinus[i2]; 
              #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
          else:
              aBot[i2] = aPlus[i2];
    
    ax[2].bar(np.arange(len(xi)),a,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
    
        
    for i2 in range(len(xi)):
        if a[i2]<=0:
            aMinus[i2] += a[i2];
        else:
            aPlus[i2] += a[i2];
    if max(aPlus)>aMax:
        aMax = max(aPlus);
    if min(aMinus)<aMin:
        aMin = min(aMinus);
if aMax>aMaxT:
    aMaxT = aMax;
if aMin<aMinT:
    aMinT =aMin;

ax[2].set_xticks([0,0,1,2,3,3.5]);
ax[2].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
ax[2].set_yticks(np.array([-7,-5,-3,0,5,10,15,20,24])*1e6);
ax[2].set_ylim([-8e6,24e6]);
ax[2].set_yticklabels(['','-5','-3','0','5','10','15','20',''],fontsize=19,fontweight='bold');
ax[2].text(1,-15e6,'(b)', fontsize=30,fontweight='bold');

ax[2].text(-0.8,24.3e6,'TWh',fontsize=20,fontweight='bold');
ax[2].set_ylabel('Change in Power Generation',fontsize=20,fontweight='bold');
ax[0].plot([-0.35,3.35],[0,0],'b-');
ax[2].plot([-0.35,3.35],[0,0],'b-');

#%% cost
df = pd.read_csv('JPoNG_Results2.csv');
df =df.sort_values('reduc-goal');
LDES = 'no-metal-air';
df = df[df['Metal-air-cost']==LDES];
df['Gen/Str Inv+FOM'] = df['est-cost']+df['FOM']+df['storage1-cost']+df['storage2-cost'];
df['Pipe/Str Inv+FOM'] = df['inv-storage']+df['FOM-storage']+df['pipe-est-cost'];

zeta = np.round(np.arange(0.8,1,0.05),2);
scen = ['RM','HM'];
import matplotlib.patches as patches
cases=[3,4];
bw = 0.7;
costs= [ 'decom-cost','VOM','startup-cost',
        'tran-est-cost','CCS-cost','nuc-fuel-cost','Gen/Str Inv+FOM', 'e-shed-cost',
        'Pipe/Str Inv+FOM','NG-import-cost','LCDF-import-cost','g-shed-cost'];

lbs = ['Decom. Cost','VOM','Startup','Network Expansion','CCS',
       'Nuc. Fuel','Gen/Str Inv+FOM','Power Shedding',
       'Pipe/Str Inv+FOM', 'NG Import','LCDF Import', 'NG Shedding'];

cols = ['black','limegreen',
        'xkcd:bright pink','xkcd:bright lilac','c',
        'xkcd:cerulean blue','xkcd:dusty blue','xkcd:dark pink',
        'xkcd:squash','xkcd:petrol','xkcd:icky green','xkcd:melon'];#icky green



dfr= df[(df['Elec_scenario']==scen[0])&(df['Metal-air-cost']=='no-metal-air')];
dfh=df[(df['Elec_scenario']==scen[1])&(df['Metal-air-cost']=='no-metal-air')];

 
ar1 = dfr[(dfr['Emis-case']==cases[1])];
ah1 = dfh[(dfh['Emis-case']==cases[1])];
abot1 = np.zeros(4);abot2 = np.zeros(4);
for i in range(len(costs)):
    if i==7:continue;
    s1 = np.array(ar1[costs[i]]);
    s2 = np.array(ah1[costs[i]]);
    if i==11: s1 = s1/10; s2 = s2/10;  

    ax[4].bar([0,2.7,5.4,8.1],s1,width=bw,bottom=abot1,color = cols[i], hatch='//');
    ax[4].bar(np.array([0,2.7,5.4,8.1])+1,s2,width=bw,bottom=abot2,color = cols[i],label=lbs[i]);

    #ax[0].bar(j*2.7+np.arange(2),[s1,s2],width=bw,bottom=abot,color = cols[i],label=lbs[i]);
    abot1 += s1;
    abot2 += s2;

abot1 = np.zeros(4);abot2 = np.zeros(4);
# for i in range(len(costs)):
#     s1 = np.array(ar2[costs[i]]);
#     s2 = np.array(ah2[costs[i]]);
#     if i==11: s1 = s1/10; s2 = s2/10;  

#     ax[2].bar([0,2.7,5.4,8.1],s1,width=bw,bottom=abot1,color = cols[i], hatch='//');
#     ax[2].bar(np.array([0,2.7,5.4,8.1])+1,s2,width=bw,bottom=abot2,color = cols[i],label=lbs[i]);

#     #ax[0].bar(j*2.7+np.arange(2),[s1,s2],width=bw,bottom=abot,color = cols[i],label=lbs[i]);
#     abot1 += s1;
#     abot2 += s2;

        
ax[3].axis('off');
      
# ax[2].set_xticks([-0.8,0.5,3.2,5.9,8.6,10]);
# ax[2].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
  
ax[4].set_xticks([-0.8,0.5,3.2,5.9,8.6,10]);
ax[4].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');

ax[4].set_ylim([0,1.8e10]);
# ax[2].set_ylim([0,1.8e10]);
# ax[4].set_yticks(np.array([0,10,20,30,40,50,55])*1e9);
# ax[4].set_yticklabels(['0','10','20','30','40','50','55'],fontsize=19,fontweight='bold');

ax[4].set_yticks(np.array([0,4,8,12,16,18])*1e9);
ax[4].set_yticklabels(['','4','8','12','16',''],fontsize=19,fontweight='bold');

ax[4].legend(loc='upper center',ncol=3, bbox_to_anchor=(0.42, 1.26), prop={'size': 21});    
# ax[4].text(-0.9,5.9e10,'x10e8 ($)',fontsize=19,fontweight='bold');
ax[4].text(-0.9,18.3e9,'x10e8 ($)',fontsize=19,fontweight='bold');
props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
# ax[4].text(3,-0.7e10,'C1',
#         color = 'xkcd:yellowish',
#         fontsize=20,fontweight = 'bold',bbox=props);    
# ax[2].text(4,-2e9,'C4',
#         color = 'xkcd:yellowish',
#         fontsize=20,fontweight = 'bold',bbox=props);

ax[4].set_ylabel('Energy System Cost Components',fontsize=19,fontweight='bold');
rect = patches.Rectangle((0.5, 16e9), 1.5, 1e9, linewidth=1, edgecolor='k',hatch='//' ,facecolor='none')
ax[4].text(-0.7,16e9,'BAU',fontsize=18,fontweight = 'bold');
ax[4].add_patch(rect);

rect = patches.Rectangle((3.1, 16e9), 1.5, 1e9, linewidth=1, edgecolor='k' ,facecolor='none')
ax[4].text(2.3,16e9,'HE',fontsize=18,fontweight = 'bold');
ax[4].add_patch(rect);

ax[4].text(4,-4e9,'(c)',fontsize=30,fontweight='bold');
rect = patches.Rectangle((0.5, 16e9), 1.5, 1e9, linewidth=1, edgecolor='k',hatch='//' ,facecolor='none')


name = 'case4-BAUvsHE-cap-gen-cost.pdf';
fig.savefig(name,bbox_inches='tight');
