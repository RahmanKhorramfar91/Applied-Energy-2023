# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 09:57:10 2022

@author: Rahman Khorramfar
"""

from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
import os;

case = 4;
scen = 'RM'; #HM or RM
emis_case = 0.8;
rep_days = 30;
season = 'Winter';
LDES='no-metal-air';
# select typical winter and summer days in the 40 rep. day input
#360 (1), 362 (19), 364(1), 11(21), 15(1), 16 (11), 21 (6), 22 (1), 30 (9), 78 (13) 
winter_days =np.array([360,362,11,15,16,22,30]);


summer_days = [185,194,198, 220, 222, 224, 246];


#df = pd.read_csv('JPoNG_Results2.csv');
path = os.getcwd();
p1 = os.path.abspath(os.path.join(path, os.pardir)); #parent path

# read rep days
#p2 = p1+'\\extreme_days\\extreme_days_medians_k=40.csv';
#dfd = pd.read_csv(p2);
dfd  = [11, 15, 16, 21, 22, 30, 78, 92, 111, 152, 172, 185, 194, 198, 220, 222, 224, 246, 249, 265, 270, 273, 276, 289, 325, 327, 343, 360, 362, 364];


#read ng load data
p2 = p1+'\\Gas_System_Data\\ng_daily_load2050_'+scen+'.csv';
dfg = pd.read_csv(p2);

p2 = p1+'\\Power_System_Data\\zonal_load-'+scen+'.csv';
dfl = pd.read_csv(p2);
# NG_80_RM = [1441867.378,1747524.704,3492801.821,2151481.086,4685248.482,675790.7324,2586245.733,419866.2486,764280.8429,1801851.881,43818.26619,43500.0435,254748.1678,1509565.084,433999.2004,594374.603,1678597.736,555466.6263,959204.0091,1177534.958,3504085.441,6909674.6,522809.0058,1909598.746,1354675.678,1365642.5,2023355.368,1665538.433,2026543.724,684109.0451,2337740.645,1146290.873,1936312.104,1066151.442,0,877097.4086,879827.7918,178213.6748,3118379.312,1942918.983];
# RNG_80_RM = [1887191.428,1886985.799,1700391.428,1054483.089,1138075.182,2379088.73,1109063.536,2846080.359,1453613.58,431529.3215,1370239.737,1171218.788,106245.3875,302746.7495,300683.1878,67108.36447,190553.7332,59972.68627,254252.5767,0,397698.2922,208912.7519,106467.459,146995.3909,209422.0678,452190.0666,26458.35457,113033.2582,406062.5002,222632.3324,205952.5552,85258.6676,133127.0213,35457.88203,0,236603.0887,353816.8211,1867432.017,879924.7097,1153030.98];

# NG_80_HM = [3469761.303,2135690.203,3200078.574,2302710.03,5524909.483,1180721.716,2547323.236,1518907.77,2385437.418,1377958.778,443079.8421,860751.4658,0,880285.3495,150507.0429,148157.8582,556837.2309,84577.46304,103270.1484,168003.9759,2292517.124,5643427.48,79099.70045,1179215.769,381674.8474,875977.5469,1499947.578,831176.7002,2025750.49,214499.1444,829128.2495,390824.2409,1835114.852,644096.9407,0,803080.0099,43500.04358,77998.91426,4670556.607,2090798.559];
# RNG_80_HM = [935260.3433,1828366.022,2373844.493,1322514.712,2275696.202,1368542.852,1428013.438,2326452.493,475406.0775,777442.311,784945.8136,208501.4469,241196.4707,448439.3338,525120.6434,528140.4443,374399.9281,485040.2265,448206.7764,480918.4659,351954.1592,296048.7626,456210.6695,437129.5655,497676.8384,215955.6957,299695.3027,359310.0296,231892.228,414276.364,314830.9967,446194.1056,278836.0078,386749.1571,0,296320.1853,1034606.901,1635019.844,783363.6909,2018796.566];


# read hourly/daily params
p1 = os.getcwd();
p2 = p1+'\\all-vars\\6-30-'+str(scen)+'-'+str(case)+'-'+str(emis_case)+'-0.5-'+LDES+'.csv';
dfv = pd.read_csv(p2);
s1 = dfv.columns.get_loc('ng-supply(1-18)-(day by node)');
NG_import = dfv.iloc[:365,s1:s1+18];
NG_import= np.array(NG_import.sum(axis=1));

s1 = dfv.columns.get_loc('LCDF-supply(1-18)-(day by node)');
RNG_import = dfv.iloc[:365,s1:s1+18];
RNG_import= np.array(RNG_import.sum(axis=1));
# find the index of typicla winer and summer days in teh 40-rep data
wi = np.zeros(len(winter_days));
si = np.zeros(len(summer_days));
ng_load = np.zeros(len(summer_days));
doy = np.array(dfd);
for i in range(len(winter_days)):
    s1 = np.where(doy==winter_days[i]);    
    wi[i] = int(s1[0][0]);
    s1 = np.where(doy==summer_days[i]);    
    si[i] = int(s1[0][0]);
    
rngImp = np.zeros(len(summer_days));
ngImp = np.zeros(len(summer_days));
days = 0;di = 0;
if season=='Winter':
    days = winter_days;
    di = wi;
    for i in range(len(ngImp)):
        ngImp[i] =  NG_import[winter_days[i]];
        rngImp[i] = RNG_import[winter_days[i]];
         
if season=='Summer':
    days = summer_days;
    di = si;
    for i in range(len(ngImp)):
        ngImp[i] =  NG_import[winter_days[i]];
        rngImp[i] = RNG_import[winter_days[i]];
                
for i in range(len(days)):
    ng_load[i] = sum(dfg.iloc[days[i],1:19]);
    
hours = np.zeros(24*len(di),dtype=int); #hours in the 40-rep all-var results
pow_load = np.zeros(24*len(di),dtype=int); # actual hours to plot power load 
for i in range(len(di)):
    hours[i*24:i*24+24] = np.arange(24*(di[i]),24*di[i]+24);
    s1 = np.arange(24*(days[i]),24*days[i]+24);
    s2 = np.array((dfl.iloc[s1,1:]));
    pow_load[i*24:i*24+24] = np.sum(s2,1);

del p1,p2,path,s1,s2;

lbs = ['ng','solar','wind','hydro','nuclear',
       'OCGT','CCGT','CCGT-CCS',
       'solar-UPV','wind-new','wind-offshore','nuclear-new','Charge','Discharge'];

cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','orange','purple','m'];

order = [4,11,3,0,5,6,7,2,9,10,1,8,13,12];
lbs = [lbs[i] for i in order];
cols =[cols[i] for i in order];

fig, ax = plt.subplots(nrows=2, ncols=1, figsize=(12, 8),
                       gridspec_kw={
                       'width_ratios': [10],'height_ratios': [5,2],                           
                       'wspace': 0.2, 'hspace': 0.2});

bottom = np.zeros(len(hours));
bw = 1;alpha=0.75;
for i in range(len(lbs)):
    a1 = dfv[lbs[i]].iloc[hours];
    if lbs[i]=='CCGT' or lbs[i]=='OCGT' or lbs[i]=='nuclear-new': continue;
    
    if lbs[i] == 'Charge':
        ax[0].bar(
        np.arange(len(hours)),-a1,
        width=bw,color = cols[i],label='Battery Ch.',alpha=alpha);        
    elif lbs[i]=='Discharge':
        ax[0].bar(
        np.arange(len(hours)),a1,
        width=bw,color = cols[i],
        bottom=bottom,label='Battery Dis.',alpha=alpha);
    else:
        ax[0].bar(
        np.arange(len(hours)),a1,
        width=bw,color = cols[i],
        bottom=bottom,label=lbs[i],alpha=alpha);
    bottom += a1;   

ax[0].plot(np.arange(len(pow_load)),pow_load,'r-',label='Power Load');

ax[0].set_xlim([-2,len(hours)+2]);
ax[0].legend(loc='upper center',ncol=4, bbox_to_anchor=(0.52, 1.32), prop={'size': 15});

ax[0].set_xticks([0,23,47,71,95,119,143,167]);
# ax[0].plot([23,23],[0,32e3],linewidth=1);
ax[0].set_xticklabels(['1','24','48','72','96','120','144','168'],fontsize=15,fontweight='bold');

mx = max(bottom);
mn = max(dfv['Charge'].iloc[hours]);

ax[0].set_yticks([-7e3,-5e3,0,5e3,10e3,15e3,20e3,25e3,30e3,32e3]);
ax[0].set_yticklabels(['','-5','0','5','10','15','20','25','30',''],fontsize=15,fontweight='bold')
ax[0].text(-4,34e3,'GW',fontsize=16,fontweight='bold');   
ax[0].set_ylabel('Generation',fontsize=16,fontweight='bold'); 
#plt.subplots_adjust(hspace=0.3);
#fig.tight_layout(pad=1)
ax[0].text(172,-10e3,'(h)',fontsize=16,fontweight='bold');




# draw the daily load of NG
bw = 0.15;
ax[1].bar(np.arange(len(ng_load)),ng_load,width=bw,color = 'black',alpha=0.65,label='Non-power NG demand');
ax[1].bar(np.arange(len(ng_load))+0.2,ngImp,width=bw,color = 'xkcd:red brown',alpha=0.65, label = 'NG Import');
ax[1].bar(np.arange(len(ng_load))+0.2,rngImp,bottom=ngImp,width=bw,color = 'xkcd:sapphire',alpha=0.65, label='LCDF Import');

ax[1].set_xticks([0.1,1.1,2.1,3.1,4.1,5.1,6.1]);
ax[1].set_xticklabels(['Day 1','Day 2','Day 3','Day 4','Day 5','Day 6','Day 7'],fontsize=15,fontweight='bold');
mx = max(ng_load);

ax[1].set_yticks([0,15e5,30e5,45e5,6e6,7.5e6]);
ax[1].set_yticklabels(['','15','30','45','60',''],fontsize=14,fontweight='bold');
ax[1].text(-0.6,7.7e6,'x10e4 MMBtu',fontsize=13,fontweight='bold');
#ax[1].set_ylabel('NG Load',fontsize=16,fontweight='bold');
ax[1].legend(loc='upper center',ncol=3, bbox_to_anchor=(0.72, 1), prop={'size': 10});

name = 'hourly-gen-mix-C'+str(case)+'-'+season+'-'+str(scen)+'-'+str(np.round(emis_case*100))+'.pdf';
fig.savefig(name,bbox_inches='tight');        










