# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 17:18:49 2022
Fig 5
@author: Rahman Khorramfar
"""

from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
# import geopandas as gpd;
# import networkx as nx;
# import os;

df = pd.read_csv('JPoNG_Results2.csv');
df =df.sort_values('reduc-goal');
xi = np.arange(0.8,1,0.05);
scen = ['RM','HM'];
df['Gen/Str Inv+FOM'] = df['est-cost']+df['FOM']+df['storage1-cost']+df['storage2-cost'];
df['Pipe/Str Inv+FOM'] = df['inv-storage']+df['FOM-storage']+df['pipe-est-cost'];


fig, ax = plt.subplots(nrows=1, ncols=8, figsize=(36, 12),
                       gridspec_kw={
                           'width_ratios': [10,10,1,10,10,1,10,10],
                           'height_ratios': [5],
                       'wspace': 0.1,
                       'hspace': 0.1});

#%% cap
bw = 0.7;
lbs_est = ['ng.1','solar.1','wind.1','hydro.1','nuclear.1',
       'OCGT.1','CCGT.1','CCGT-CCS.1',
       'solar-UPV.1','wind-new.1','wind-offshore.1','nuclear-new.1'];

lbs_dec = ['ng.2','solar.2','wind.2','hydro.2','nuclear.2',
       'OCGT.2','CCGT.2','CCGT-CCS.2',
       'solar-UPV.2','wind-new.2','wind-offshore.2','nuclear-new.2'];
lbs = ['ng','solar','wind','hydro','nuclear',
       'OCGT','CCGT','CCGT-CCS',
       'solar-UPV','wind-new','wind-offshore','nuclear-new','Li-ion'];

cap = np.array([173,6.3,42,23,933,237,	573,	400,	10,	10,	10,	360]);# nameplate cap for new plants
exis_plant_num = np.array([92,71,24,112,4,0,0,0,0,0,0,0]);
cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','orange','xkcd:purpleish'];
order = [4,11,3,0,5,6,7,2,9,10,1,8];
#order = [2,9,10, 4,11, 0,5,6,7, 1,8];
lbs_est = [lbs_est[i] for i in order];
lbs_dec = [lbs_dec[i] for i in order];
cap = [cap[i] for i in order];
exis_plant_num = [exis_plant_num[i] for i in order];
order = [4,11,3,0,5,6,7,2,9,10,1,8,12];
#order = [2,9,10, 4,11, 0,5,6,7, 1,8,12];
cols =[cols[i] for i in order];
lbs = [lbs[i] for i in order];

for j in range(len(scen)):
    aMax = 0;
    aMin = 0;
    aMinus = np.zeros(len(xi));
    aPlus = np.zeros(len(xi));
    for i in range(len(lbs_est)):
        #a = np.zeros(len(xi));
        a1 = df[(df['Emis-case']==2)& (df['Elec_scenario']==scen[j])];
        a2 = df[(df['Emis-case']==3)& (df['Elec_scenario']==scen[j])];
        #a2=100*a1[lbs[i]]/a1['prod-sum'];
        ao1 = np.array(exis_plant_num[i]+a1[lbs_est[i]])-np.array(a1[lbs_dec[i]]);
        ao2 = np.array(exis_plant_num[i]+a2[lbs_est[i]])-np.array(a2[lbs_dec[i]]);
        
        a = (ao2-ao1)*cap[i];
        
        aBot = np.zeros(len(xi));
        for i2 in range(len(xi)):
             if a[i2]<=0:
                 aBot[i2] = aMinus[i2]; 
                 #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
             else:
                 aBot[i2] = aPlus[i2];
        
        ax[j].bar(np.arange(len(xi)),a,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
        
        
        if max(aPlus)>aMax:
            aMax = max(aPlus);
        if min(aMinus)<aMin:
            aMin = min(aMinus);
            
        for i2 in range(len(xi)):
            if a[i2]<=0:
                aMinus[i2] += a[i2];
            else:
                aPlus[i2] += a[i2];
    
    
    a = np.array(a2['total-str1-cap'])-np.array(a1['total-str1-cap']);
    for i2 in range(len(xi)):
     if a[i2]<=0:
         aBot[i2] = aMinus[i2]; 
         #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
     else:
         aBot[i2] = aPlus[i2];
    

    ax[j].bar(np.arange(len(xi)),a,width=bw,color = cols[-1],bottom=aBot,label=lbs[-1]);
    # for i2 in range(len(xi)):
    #     if a[i2]<=0:
    #         aMinus[i2] += a[i2];
    #     else:
    #         aPlus[i2] += a[i2];
    ax[j].set_xticks([0,0,1,2,3,3.5]);
    ax[j].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
    ax[j].set_yticks(np.array([-5,-4,-2,0,10,20,30,35,40])*1e3);
    ax[j].set_ylim([-5000,40000]);
    if j==0:
        ax[j].set_yticklabels(['','-4','-2','0','10','20','30','35',''],fontsize=19,fontweight='bold');
    else:
        ax[j].set_yticklabels(['','','','','','','','',''],fontsize=19,fontweight='bold');

ax[0].legend(loc='upper center',ncol=5, bbox_to_anchor=(1.9, 1.27), prop={'size': 24});

ax[0].xaxis.set_label_coords(1.1, -0.05);

ax[0].text(1.3,-1e4,'Emission Reduction Goals (%)',fontsize=21,fontweight='bold');

ax[0].text(-0.8,40.2e3,'GW',fontsize=20,fontweight='bold');
ax[0].set_ylabel('Change in Generation Capacity',fontsize=20,fontweight='bold');

props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
ax[0].text(0,-11000,'BAU',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[1].text(1.9,-11000,'HE',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[0].text(3.2,-15000,'(a)',fontsize=30,fontweight='bold');
# name = 'diff-plot-case-1vs2-cap.pdf';
# fig.savefig(name,bbox_inches='tight');
#%% gen
# fig, ax = plt.subplots(1,2,figsize=(12,12));
ax[2].axis('off');

bw = 0.7;
lbs = ['ng','solar','wind','hydro','nuclear',
        'OCGT','CCGT','CCGT-CCS',
        'solar-UPV','wind-new','wind-offshore','nuclear-new'];

cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','orange'];
order = [4,11,3,0,5,6,7,2,9,10,1,8];
lbs = [lbs[i] for i in order];
cols =[cols[i] for i in order];

aMaxT=0;
aMinT=0;
for j in range(len(scen)):
    aMax = 0;
    aMin = 0;
    
    aMinus = np.zeros(len(xi));
    aPlus = np.zeros(len(xi));
    for i in range(len(lbs)):
        #a = np.zeros(len(xi));
        a1 = df[(df['Emis-case']==2)& (df['Elec_scenario']==scen[j])];
        a2 = df[(df['Emis-case']==3)& (df['Elec_scenario']==scen[j])];
        #a2=100*a1[lbs[i]]/a1['prod-sum'];
        a = np.array(a2[lbs[i]])-np.array(a1[lbs[i]]);
        # if i==len(lbs)-1:
        #     a = a*8760;
        aBot = np.zeros(len(xi));
        for i2 in range(len(xi)):
              if a[i2]<=0:
                  aBot[i2] = aMinus[i2]; 
                  #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
              else:
                  aBot[i2] = aPlus[i2];
        
        ax[j+3].bar(np.arange(len(xi)),a,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
        
            
        for i2 in range(len(xi)):
            if a[i2]<=0:
                aMinus[i2] += a[i2];
            else:
                aPlus[i2] += a[i2];
        if max(aPlus)>aMax:
            aMax = max(aPlus);
        if min(aMinus)<aMin:
            aMin = min(aMinus);
    if aMax>aMaxT:
        aMaxT = aMax;
    if aMin<aMinT:
        aMinT =aMin;
    ax[j+3].set_xticks([0,0,1,2,3,3.5]);
    ax[j+3].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
    ax[j+3].set_yticks(np.array([-45,-40,-30,-20,-10,0,15,30,45,50])*1e6);
    ax[j+3].set_ylim([-45e6,50e6]);
    if j==0:
        ax[j+3].set_yticklabels(['','-40','-30','-20','-10','0','15','30','45',''],fontsize=19,fontweight='bold');
    else:
        ax[j+3].set_yticklabels(['','','','','','','','','',''],fontsize=19,fontweight='bold');

#ax.text(3.6,-4,'$\\xi$',fontsize=18,fontweight='bold');

#ax[4].legend(loc='upper center',ncol=1, bbox_to_anchor=(1.45, 0.7), prop={'size': 22});

ax[0+3].xaxis.set_label_coords(1.1, -0.05);

ax[0+3].text(1.3,-55e6,'Emission Reduction Goals (%)',fontsize=20,fontweight='bold');

ax[0+3].text(-0.8,52e6,'TWh',fontsize=20,fontweight='bold');
ax[0+3].set_ylabel('Change in Power Generation',fontsize=21,fontweight='bold');

props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
ax[0+3].text(0,-57e6,'BAU',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[1+3].text(2,-57e6,'HE',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[3].text(3.2,-66e6,'(b)',fontsize=30,fontweight='bold');

ax[0].plot([-0.35,3.35],[0,0],'b-');
ax[1].plot([-0.35,3.35],[0,0],'b-')
ax[3].plot([-0.35,3.35],[0,0],'b-')
ax[4].plot([-0.35,3.35],[0,0],'b-');




#%% cost
ax[5].axis('off');
df = pd.read_csv('JPoNG_Results2.csv');
df =df.sort_values('reduc-goal');
df['Gen/Str Inv+FOM'] = df['est-cost']+df['FOM']+df['storage1-cost']+df['storage2-cost'];
df['Pipe/Str Inv+FOM'] = df['inv-storage']+df['FOM-storage']+df['pipe-est-cost'];

zeta = np.round(np.arange(0.8,1,0.05),2);
scen = ['RM','HM'];

cases=[2,3];
bw = 0.7;
costs= [ 'decom-cost','VOM','startup-cost',
        'tran-est-cost','CCS-cost','nuc-fuel-cost','Gen/Str Inv+FOM', 'e-shed-cost',
        'Pipe/Str Inv+FOM','NG-import-cost','LCDF-import-cost','g-shed-cost'];

lbs = ['Decom. Cost','VOM','Startup','Network Expansion','CCS',
       'Nuc. Fuel','Gen/Str Inv+FOM','Power Shedding',
       'Pipe/Str Inv+FOM', 'NG Import','LCDF Import', 'NG Shedding'];

cols = ['black','limegreen',
        'xkcd:bright pink','xkcd:bright lilac','c',
        'xkcd:cerulean blue','xkcd:dusty blue','xkcd:dark pink',
        'xkcd:squash','xkcd:petrol','xkcd:icky green','xkcd:melon'];#icky green

# dfr= df[df['Elec_scenario']==scen[0]];
# dfh=df[df['Elec_scenario']==scen[1]];
# ar1 = dfr[(df['Emis-case']==cases[0])];
# ah1 = dfh[(dfh['Emis-case']==cases[0])];
# ar2 = dfr[(dfr['Emis-case']==cases[1])];
# ah2 = dfh[(dfh['Emis-case']==cases[1])];
aMaxT=0;
aMinT=0;
for j in range(len(scen)):
    aMax = 0;
    aMin = 0;
    
    aMinus = np.zeros(len(xi));
    aPlus = np.zeros(len(xi));  
    a1 = df[(df['Emis-case']==2)& (df['Elec_scenario']==scen[j])];
    a2 = df[(df['Emis-case']==3)& (df['Elec_scenario']==scen[j])];      

    for i in range(len(costs)):
        if lbs[i]=='Power Shedding' or lbs[i]=='LCDF Import': continue;

        ar = np.array(a2[costs[i]])-np.array(a1[costs[i]]);
        # if i==len(lbs)-1:
        #     a = a*8760;
        if i==11:
            ar = ar/10;
        if abs(sum(ar))<1:
            continue;
        aBot = np.zeros(len(xi));
        for i2 in range(len(xi)):
              if ar[i2]<=0:
                  aBot[i2] = aMinus[i2]; 
                  #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
              else:
                  aBot[i2] = aPlus[i2];
        
        ax[j+6].bar(np.arange(len(xi)),ar,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
        
            
        for i2 in range(len(xi)):
            if ar[i2]<=0:
                aMinus[i2] += ar[i2];
            else:
                aPlus[i2] += ar[i2];
        if max(aPlus)>aMax:
            aMax = max(aPlus);
        if min(aMinus)<aMin:
            aMin = min(aMinus);
    if aMax>aMaxT:
        aMaxT = aMax;
    if aMin<aMinT:
        aMinT =aMin;
    ax[j+6].set_xticks([0,0,1,2,3,3.5]);
    ax[j+6].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
    ax[j+6].set_yticks(np.array([-5,-3,0,15,30,45,50])*1e9);
    ax[j+6].set_ylim([-4e9,50e9]);
    if j==0:
        ax[j+6].set_yticklabels(['','-3','0','15','30','45',''],fontsize=19,fontweight='bold');
    else:
        ax[j+6].set_yticklabels(['','','','','','',''],fontsize=19,fontweight='bold');

ax[0+6].xaxis.set_label_coords(1.1, -0.05);

ax[0+6].text(1.25,-95e8,'Emission Reduction Goals (%)',fontsize=21,fontweight='bold');
ax[0+6].text(-0.8,51e9,'x10e8 ($)',fontsize=20,fontweight='bold');
ax[0+6].set_ylabel('Change in Cost Components',fontsize=20,fontweight='bold');
props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
ax[0+6].text(0,-107e8,'BAU',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[1+6].text(2,-107e8,'HE',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[6].plot([-0.35,3.35],[0,0],'b-');
ax[7].plot([-0.35,3.35],[0,0],'b-');
ax[6].legend(loc='upper center',ncol=3, bbox_to_anchor=(0.84, 1.28), prop={'size': 24});
ax[6].text(3.2,-160e8,'(c)',fontsize=30,fontweight='bold');


name = 'diff-plot-case-2vs3-cap-gen-cost.pdf';
fig.savefig(name,bbox_inches='tight');

