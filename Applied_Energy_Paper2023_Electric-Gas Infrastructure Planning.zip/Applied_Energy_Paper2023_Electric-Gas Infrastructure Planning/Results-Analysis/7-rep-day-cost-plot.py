# -*- coding: utf-8 -*-
"""
Created on Tue Aug 16 20:49:20 2022

@author: Rahman Khorramfar
"""

from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;


df = pd.read_csv('JPoNG_Results-rep-day-costs.csv');
df['Gen/Str Inv+FOM'] = df['est-cost']+df['FOM']+df['storage1-cost']+df['storage2-cost'];
df['Pipe/Str Inv+FOM'] = df['inv-storage']+df['FOM-storage']+df['pipe-est-cost'];

#rw = df['Rep-Days'];
rw = np.arange(11,29,2);
rw2 = np.arange(29,31,1);
rw3=np.arange(31,36,2);
rw = [*rw,*rw2,*rw3];
df=df[df['Rep-Days'].isin(rw)];
nRep = np.array(df['Rep-Days']);

#%% system costs
#fig, ax = plt.subplots(figsize=(12,8));
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(12, 12),
                       gridspec_kw={
                           'width_ratios': [10,],
                           'height_ratios': [10],
                       'wspace': 0.2,
                       'hspace': 0.2});

vr = matplotlib.cm.get_cmap('Dark2',10);
vr = vr.colors;

CC = np.array(df['Total-cost']);
#CC = CC/max(CC);
ax.plot(nRep,CC,color=vr[4,:-1], marker='s',markerfacecolor='black',
                markersize=9,linewidth=2,linestyle='-',label='Total Cost');


CC = np.array(df['Power-cost']);
#CC = CC/max(CC);
ax.plot(nRep,CC,color=vr[0,:-1], marker='D',markerfacecolor='black',
                markersize=9,linewidth=2,linestyle='--',label='Power System Cost');

CC = np.array(df['Gen/Str Inv+FOM']);
#CC = CC/max(CC);
ax.plot(nRep,CC,color=vr[4,:-1], marker='D',markerfacecolor='blue',
                markersize=9,linewidth=2,linestyle='dotted',label='Pow. inv. Cost');


CC = np.array(df['NG-cost']);
#CC = CC/max(CC);
ax.plot(nRep,CC,color='blue', marker='o',markerfacecolor='red',
                markersize=9,linewidth=3,linestyle='dotted',label='NG System Cost');


ax.set_xticks([11,13,17,21,25,29,30,31,33,35]);
ax.set_xticklabels(['','13','17','21','25','29','30','31','33',''],fontsize=16,fontweight='bold');

ax.set_yticks([0.4e10,0.6e10,1e10,1.4e10,1.6e10]);
ax.set_yticklabels(['','0.6','1','1.4',''],fontsize=18,fontweight='bold');
ax.legend(loc='upper center',ncol=2, bbox_to_anchor=(0.55, 1.12), prop={'size': 17});
ax.text(9,1.6e10,'x1e10',fontsize=18,fontweight='bold');
ax.set_xlabel('Number of Representative Days',fontsize=18,fontweight='bold')
ax.set_ylabel('Objective Function Value',fontsize=18,fontweight='bold');





# CC = np.array(df['startup-cost']);
# #CC = CC/max(CC);
# ax[1].plot(nRep,CC,color=vr[0,:-1], marker='D',markerfacecolor='black',
#                 markersize=11,linewidth=4,linestyle='--',label='Startup Cost');


# CC = np.array(df['VOM']);
# #CC = CC/max(CC);
# ax[1].plot(nRep,CC,color='blue', marker='o',markerfacecolor='red',
#                 markersize=11,linewidth=4,linestyle='dotted',label='VOM Cost');



name = 'Rep-Costs.pdf';
fig.savefig(name,bbox_inches='tight');





