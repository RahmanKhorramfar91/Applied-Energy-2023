# -*- coding: utf-8 -*-
"""
Created on Wed Aug 24 08:18:15 2022

@author: Rahman Khorramfar
"""

from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
import geopandas as gpd;
import networkx as nx;
import os;


scenario = ['RM','HM'];
case = 4; emis = 0.95;
rep_days = 30;
LDES='no-metal-air';

#Path to New England shapefile
ShapeFilePath = os.getcwd()+r'\New_Engalnd_shape_file\NEWENGLAND_POLY.shp';
fig, ax = plt.subplots();
fig = plt.figure();
ax_map = fig.add_axes([0, 0, 2.5, 2.5]);
ax_map.axis('off');
NewEngland = gpd.read_file(ShapeFilePath)
#ax_map = fig.add_axes([0, 0, 1000, 1]);
NewEngland.plot(ax=ax_map,cmap='Pastel2_r',edgecolor="black",alpha=0.7);
pos2 = np.array([[1.4,1.5],[1,1.2],
                  [0.72,1.4],[0.75,0.55],[0.95,0.3],
                  [0.65,0.2]]);

pos=np.array([[2.5,-1],[0,-5.5],
                  [1,-4],[1.75,0.55],[0.5,-5],
                  [2,4]]);


BE_states_zone = ['ME', 'NH','VT','MA','RI','CT'];
StateDic = {0:'ME', 1:'NH', 2:'VT', 3:'MA', 4:'RI', 5:'CT'};
dict1 = {'Connecticut':'CT','Maine':'ME',
                      'Massachusetts':'MA','New Hampshire':'NH',
                      'Rhode Island':'RI','Vermont':'VT'};

lbs = ['CT','CC','CC-CCS','solar-UPV','wind-new','wind-offshore','nuclear-new'];
cols = ['xkcd:cocoa','xkcd:caramel','xkcd:sandstone','xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','orange','white'];
cap = np.array([237,	573,	400,	10,	10,	10,	360]);# nameplate cap for new plants
p1 = os.getcwd();
name = p1+'\\all-vars\\6-'+str(rep_days)+'-'+scenario[0]+'-'+str(case)+'-'+str(emis)+'-0.5-'+LDES+'.csv'';
#name = 'C:\\Users\\Rahman Khorramfar\\Desktop\\JPonG-Python-Codes\\Results-Analysis\\40-days-results\\6-40-HM-3-0.8-0.5.csv';
df = pd.read_csv(name, error_bad_lines=False);

a = df.columns.get_loc("ng-est")
df = df.iloc[:6,a+5:(a+12)];
for i in range(len(BE_states_zone)):
    df.iloc[i,:] = np.round(df.iloc[i,:]*cap/1000,1);
    
p1 = os.getcwd();
name = p1+'\\30-days-all-vars\\6-'+str(rep_days)+'-'+scenario[1]+'-'+str(case)+'-'+str(emis)+'-0.5.csv';
df2 = pd.read_csv(name); #HM

a = df2.columns.get_loc("ng-est")
df2 = df2.iloc[:6,a+5:(a+12)];
for i in range(len(BE_states_zone)):
    df2.iloc[i,:] = np.round(df2.iloc[i,:]*cap/1000,1);



for j in range(len(BE_states_zone)):
        
    ll = pos2[j];
    maxL = max(max(df2.sum(axis=1)),max(df.sum(axis=1)));
    maxJ = max(df2.sum(axis=1)[j],df.sum(axis=1)[j]);
    bw = 0.7;    
    a3 = np.zeros(2);
    ax = fig.add_axes([ll[0] , ll[1] , 0.15, 0.6*maxJ/maxL])
    yax1 = np.array(df.iloc[j,:]);yax1 = yax1[yax1>0];
    yax2 = np.array(df2.iloc[j,:]);yax2 = yax2[yax2>0];
    yax1 =np.round(np.cumsum(yax1),1);
    yax2 = np.round(np.cumsum(yax2),1);
    #yax = [yax1 if len(yax1)>len(yax2) else yax2];
    for i in range(len(lbs)):
        a2 = np.array([df.iloc[j,i],df2.iloc[j,i]]);
        ax.bar(np.arange(2),a2,width=bw,color = cols[i],bottom=a3,label=lbs[i],edgecolor = "black");
        a3 += a2;
    
    ax.set_axis_off();
    ax.text(-0.4,-1.5,'BAU',fontsize=14,fontweight = 'bold');
    ax.text(0.8,-1.5,'HE',fontsize=14,fontweight = 'bold');
    
    if j==3:
        #continue;
        ax.legend(loc='upper center',ncol=1,
                  bbox_to_anchor=(5.9, 1.4), 
                  prop={'size': 19,'weight':'bold','family':'Calibri'});
    #ax.text(-1,1,str(yax[0][0]))
    
    
    for i in range(len(yax1)):
        if i<(len(yax1)-1) and (yax1[i+1]-yax1[i])<1:
            continue;
        if i==len(yax1)-1:
            ax.text(-1.2,yax1[i],str(yax1[i]),fontsize=14,fontweight='bold');
        else:
            ax.text(-1.2,yax1[i],str(yax1[i]),fontsize=10);
        
    for i in range(len(yax2)):
        if i<(len(yax2)-1) and (yax2[i+1]-yax2[i])<1:
            continue;
        if i==len(yax2)-1:
            ax.text(1.5,yax2[i],str(yax2[i]),fontsize=14,fontweight='bold');
        else:
            ax.text(1.5,yax2[i],str(yax2[i]),fontsize=10);
    
    props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
    
    ax.text(pos[j][0],pos[j][1],
            BE_states_zone[j],color = 'xkcd:yellowish',
            fontsize=17,fontweight = 'bold',bbox=props);

name = 'map-est-'+str(case)+'-'+str(emis)+'.pdf'
fig.savefig(name,bbox_inches='tight');




