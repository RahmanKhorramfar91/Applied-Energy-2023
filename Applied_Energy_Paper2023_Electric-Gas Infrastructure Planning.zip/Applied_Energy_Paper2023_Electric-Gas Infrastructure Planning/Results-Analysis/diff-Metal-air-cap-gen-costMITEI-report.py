# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 17:18:49 2022
Fig 5
@author: Rahman Khorramfar
"""

from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
# import geopandas as gpd;
# import networkx as nx;
# import os;

df = pd.read_csv('JPoNG_Results2.csv');
df =df.sort_values('reduc-goal');
df['Gen/Str Inv+FOM'] = df['est-cost']+df['FOM']+df['storage1-cost']+df['storage2-cost'];
df['Pipe/Str Inv+FOM'] = df['inv-storage']+df['FOM-storage']+df['pipe-est-cost'];

xi = np.arange(0.8,1,0.05);
scen = ['RM','HM'];
metal_air = ['low','high'];
fig, ax = plt.subplots(nrows=1, ncols=8, figsize=(36, 12),
                       gridspec_kw={
                           'width_ratios': [10,10,1,10,10,1,10,10],
                           'height_ratios': [5],
                       'wspace': 0.15,
                       'hspace': 0.15});


#%% cap
bw = 0.7;
lbs_est = ['ng.1','solar.1','wind.1','hydro.1','nuclear.1',
       'OCGT.1','CCGT.1','CCGT-CCS.1',
       'solar-UPV.1','wind-new.1','wind-offshore.1','nuclear-new.1'];

lbs_dec = ['ng.2','solar.2','wind.2','hydro.2','nuclear.2',
       'OCGT.2','CCGT.2','CCGT-CCS.2',
       'solar-UPV.2','wind-new.2','wind-offshore.2','nuclear-new.2'];
lbs = ['ng','solar','wind','hydro','nuclear',
       'OCGT','CCGT','CCGT-CCS',
       'solar-UPV','wind-new','wind-offshore','nuclear-new','Li-ion','Metal-air'];

cap = np.array([173,6.3,42,23,933,237,	573,	400,	10,	10,	10,	360]);# nameplate cap for new plants
exis_plant_num = np.array([92,71,24,112,4,0,0,0,0,0,0,0]);
cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald',
        'orange','xkcd:purpleish','xkcd:carnation'];
order = [4,11,3,0,5,6,7,2,9,10,1,8];
#order = [2,9,10, 4,11, 0,5,6,7, 1,8];
lbs_est = [lbs_est[i] for i in order];
lbs_dec = [lbs_dec[i] for i in order];
cap = [cap[i] for i in order];
exis_plant_num = [exis_plant_num[i] for i in order];
order = [4,11,3,0,5,6,7,2,9,10,1,8,12,13];
#order = [2,9,10, 4,11, 0,5,6,7, 1,8,12];
cols =[cols[i] for i in order];
lbs = [lbs[i] for i in order];

for j in range(len(scen)):
    aMax = 0;
    aMin = 0;
    aMinus = np.zeros(len(xi));
    aPlus = np.zeros(len(xi));
    for i in range(len(lbs_est)):
        if i==1 or i==4 or i==5 or i==7 or i==10: continue;

        #a = np.zeros(len(xi));
        a1 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[1])&(df['Metal-air-cost']=='no-metal-air')];
        a2 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[1])&(df['Metal-air-cost']==metal_air[j])];
        #a2=100*a1[lbs[i]]/a1['prod-sum'];
        ao1 = np.array(exis_plant_num[i]+a1[lbs_est[i]])-np.array(a1[lbs_dec[i]]);
        ao2 = np.array(exis_plant_num[i]+a2[lbs_est[i]])-np.array(a2[lbs_dec[i]]);
        
        a = (ao2-ao1)*cap[i];
        
        aBot = np.zeros(len(xi));
        for i2 in range(len(xi)):
             if a[i2]<=0:
                 aBot[i2] = aMinus[i2]; 
                 #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
             else:
                 aBot[i2] = aPlus[i2];
        
        ax[j].bar(np.arange(len(xi)),a,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
        
        
        if max(aPlus)>aMax:
            aMax = max(aPlus);
        if min(aMinus)<aMin:
            aMin = min(aMinus);
            
        for i2 in range(len(xi)):
            if a[i2]<=0:
                aMinus[i2] += a[i2];
            else:
                aPlus[i2] += a[i2];
    
    
    a = np.array(a2['total-str1-cap'])-np.array(a1['total-str1-cap']);
    for i2 in range(len(xi)):
     if a[i2]<=0:
         aBot[i2] = aMinus[i2]; 
         #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
     else:
         aBot[i2] = aPlus[i2];
    ax[j].bar(np.arange(len(xi)),a,width=bw,color = cols[-2],bottom=aBot,label=lbs[-2]);

    for i2 in range(len(xi)):
        if a[i2]<=0:
            aMinus[i2] += a[i2];
        else:
            aPlus[i2] += a[i2];


    a = np.array(a2['total-str2-cap'])-np.array(a1['total-str2-cap']);
    for i2 in range(len(xi)):
     if a[i2]<=0:
         aBot[i2] = aMinus[i2]; 
         #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
     else:
         aBot[i2] = aPlus[i2];
    
    
    ax[j].bar(np.arange(len(xi)),a,width=bw,color = cols[-1],bottom=aBot,label=lbs[-1]);


    ax[j].set_xticks([0,0,1,2,3,3.5]);
    ax[j].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
    ax[j].set_yticks(np.array([-12,-10,-5,0,5,10,15,16])*1e3);
    ax[j].set_ylim([-12300,16000]);
    if j==0:
        ax[j].set_yticklabels(['','-10','-5','0','5','10','15',''],fontsize=19,fontweight='bold');
    else:
        ax[j].set_yticklabels(['','','','','','','',''],fontsize=19,fontweight='bold');

# ax[0].legend(loc='upper center',ncol=1, bbox_to_anchor=(5.2, 0.8), prop={'size': 20});

ax[0].xaxis.set_label_coords(1.1, -0.05);
ax[0].legend(loc='upper center',ncol=4, bbox_to_anchor=(1.8, 1.27), prop={'size': 26});

ax[0].text(1.3,-15500,'Emission Reduction Goals (%)',fontsize=25,fontweight='bold');

ax[0].text(-0.8,16.4e3,'GW',fontsize=20,fontweight='bold');
ax[0].set_ylabel('Change in Generation Capacity',fontsize=20,fontweight='bold');
ax[0].text(3,-20e3,'(a)',fontsize=30,fontweight='bold');
props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
ax[0].text(0,-18500,'low',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[1].text(1.9,-18500,'high',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
#%% gen
# fig, ax = plt.subplots(1,2,figsize=(12,12));
ax[2].axis('off');

bw = 0.7;
lbs = ['ng','solar','wind','hydro','nuclear',
        'OCGT','CCGT','CCGT-CCS',
        'solar-UPV','wind-new','wind-offshore','nuclear-new'];

cols = ['xkcd:deep brown','xkcd:off yellow','olivedrab','xkcd:dark sky blue','xkcd:rusty red',
        'xkcd:cocoa','xkcd:caramel','xkcd:sandstone',
        'xkcd:piss yellow','xkcd:dark lime','xkcd:emerald','orange'];
order = [4,11,3,0,5,6,7,2,9,10,1,8];
lbs = [lbs[i] for i in order];
cols =[cols[i] for i in order];

aMaxT=0;
aMinT=0;
for j in range(len(scen)):
    aMax = 0;
    aMin = 0;
    
    aMinus = np.zeros(len(xi));
    aPlus = np.zeros(len(xi));
    for i in range(len(lbs)):
        if i==1 or i==4 or i==5 or i==7 or i==10: continue;

        #a = np.zeros(len(xi));
        a1 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[1])&(df['Metal-air-cost']=='no-metal-air')];
        a2 = df[(df['Emis-case']==4)& (df['Elec_scenario']==scen[1])&(df['Metal-air-cost']==metal_air[j])];
        #a2=100*a1[lbs[i]]/a1['prod-sum'];
        a = np.array(a2[lbs[i]])-np.array(a1[lbs[i]]);
        # if i==len(lbs)-1:
        #     a = a*8760;
        aBot = np.zeros(len(xi));
        for i2 in range(len(xi)):
              if a[i2]<=0:
                  aBot[i2] = aMinus[i2]; 
                  #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
              else:
                  aBot[i2] = aPlus[i2];
        
        ax[j+3].bar(np.arange(len(xi)),a,width=bw,color = cols[i],bottom=aBot,label=lbs[i]);
        
            
        for i2 in range(len(xi)):
            if a[i2]<=0:
                aMinus[i2] += a[i2];
            else:
                aPlus[i2] += a[i2];
        if max(aPlus)>aMax:
            aMax = max(aPlus);
        if min(aMinus)<aMin:
            aMin = min(aMinus);
    if aMax>aMaxT:
        aMaxT = aMax;
    if aMin<aMinT:
        aMinT =aMin;
    ax[j+3].set_xticks([0,0,1,2,3,3.5]);
    ax[j+3].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
    ax[j+3].set_yticks(np.array([-25,-20,-15,-10,-5,0,5,10,15,20,25,30,35])*1e6);
    ax[j+3].set_ylim([-25e6,35e6]);
    if j==0:
        ax[j+3].set_yticklabels(['','-20','-15','-10','-5','0','5','10','15','20','25','30',''],fontsize=19,fontweight='bold');
    else:
        ax[j+3].set_yticklabels(['','','','','','','','','','','','',''],fontsize=19,fontweight='bold');

#ax.text(3.6,-4,'$\\xi$',fontsize=18,fontweight='bold');

#ax[4].legend(loc='upper center',ncol=1, bbox_to_anchor=(1.45, 0.7), prop={'size': 22});

ax[0+3].xaxis.set_label_coords(1.1, -0.05);

ax[0+3].text(1.3,-32e6,'Emission Reduction Goals (%)',fontsize=25,fontweight='bold');

ax[0+3].text(-0.8,35.6e6,'TWh',fontsize=20,fontweight='bold');
ax[0+3].set_ylabel('Change in Power Generation',fontsize=20,fontweight='bold');

props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
ax[0+3].text(0,-38e6,'low',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[1+3].text(2,-38e6,'high',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[3].text(3,-41e6,'(b)',fontsize=30,fontweight='bold');
ax[0].plot([-0.35,3.35],[0,0],'b-');
ax[1].plot([-0.35,3.35],[0,0],'b-');
ax[3].plot([-0.35,3.35],[0,0],'b-');
ax[4].plot([-0.35,3.35],[0,0],'b-');

#%% 
ax[5].axis('off');
costs= [ 'decom-cost','VOM','startup-cost',
        'tran-est-cost','CCS-cost','nuc-fuel-cost','Gen/Str Inv+FOM',
        'Pipe/Str Inv+FOM','NG-import-cost','LCDF-import-cost'];

lbs = ['Decom. Cost','VOM','Startup','Network Expansion','CCS',
       'Nuc. Fuel','Gen/Str Inv+FOM',
       'Pipe/Str Inv+FOM', 'NG Import','LCDF Import'];


cols = ['black','limegreen',
        'xkcd:orangish','xkcd:bright lilac','c',
        'xkcd:cerulean blue','xkcd:dusty blue',
        'xkcd:squash','xkcd:dark pink','xkcd:icky green'];#icky green

dfr= df[df['Elec_scenario']==scen[1]];
dfh= df[df['Elec_scenario']==scen[1]];

    

for j in range(2):
    ar1 = dfr[(df['Elec_scenario']==scen[1]) & (dfr['Emis-case']==4)&(df['Metal-air-cost']=='no-metal-air')];
    ah1 = dfh[(df['Elec_scenario']==scen[1]) & (dfh['Emis-case']==4)&(df['Metal-air-cost']==metal_air[j])];

    neg = np.zeros(len(xi)); pos = np.zeros(len(xi));
    abot = np.zeros(len(xi));
    for i in range(len(costs)):
        ar = np.array(ar1[costs[i]]);
        ah = np.array(ah1[costs[i]]);
        a = ah-ar;
        
        for i2 in range(len(a)):        
            if a[i2]<=0:
                abot[i2] = neg[i2]; 
            #ax[0].bar(i2,a[i2],width=bw,color = cols[i],bottom=aMinus[i2],label=lbs[i]);
            else:
                abot[i2] = pos[i2];
            
        ax[j+6].bar(np.arange(4),a,width=bw,bottom=abot,color = cols[i],label=lbs[i]);
        
        for i2 in range(len(a)):
            if a[i2]<=0:
                neg[i2] += a[i2];
            else:
                pos[i2] += a[i2];

    ax[j+6].set_xticks([0,0,1,2,3,3.5]);
    ax[j+6].set_xticklabels(['','80','85','90','95',''],fontsize=19,fontweight='bold');
    ax[j+6].set_yticks(np.array([-165,-140,-100,-75,-50,-25,0,25,50,75,76])*1e7);
    ax[j+6].set_ylim([-155e7,76e7]);
    if j==0:
        ax[j+6].set_yticklabels(['','-140','-100','-75','-50','-25','0','25','50','',''],fontsize=19,fontweight='bold');
    else:
        ax[j+6].set_yticklabels(['','','','','','','','','','',''],fontsize=19,fontweight='bold');

ax[6].legend(loc='upper center',ncol=3, bbox_to_anchor=(0.5, 1.31), prop={'size': 26});
ax[6].set_ylabel('Change in Cost Components',fontsize=20,fontweight='bold')
ax[6].text(1.3,-183e7, 'Emission Reduction Goals (%)',fontsize=25,fontweight='bold');
ax[6].text(-0.8,78e7,'x10e6 ($)',fontsize=22,fontweight='bold');

ax[6].plot([-0.35,3.35],[0,0],'b-');
ax[7].plot([-0.35,3.35],[0,0],'b-');
props = dict(boxstyle='round', facecolor='xkcd:dark olive', alpha=1);
ax[6].text(0,-203e7,'low',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[7].text(2,-203e7,'high',color = 'xkcd:yellowish',
        fontsize=30,fontweight = 'bold',bbox=props);
ax[6].text(3,-213e7,'(c)',fontsize=30,fontweight='bold');

name = 'diff-plot-metal-air-cap-gen-cost-MITEI-report.pdf';
fig.savefig(name,bbox_inches='tight');

