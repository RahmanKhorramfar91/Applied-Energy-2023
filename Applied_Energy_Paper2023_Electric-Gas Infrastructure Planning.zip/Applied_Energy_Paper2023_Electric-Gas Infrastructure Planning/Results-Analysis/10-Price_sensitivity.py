# -*- coding: utf-8 -*-
"""
Created on Fri Jun 16 19:22:14 2023

@author: Rahman Khorramfar
"""


from IPython import get_ipython;
get_ipython().magic('reset -f') # to clear the namespace
get_ipython().magic('clear');
import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import matplotlib;
import networkx as nx;
import os;
from matplotlib import cm
from matplotlib.colors import ListedColormap, LinearSegmentedColormap

df = pd.read_csv('RNG-NG-Price-Sensitivity.csv')
costs=['Total-cost','storage1-cost','VRE-cap','gas-fired-prod'];
lbs = ['Total System Cost ($)','Electricity Storage Cost ($)', 'VRE Capacity (MW)','Gas-fired Plants Gen. (MWh)'];
RNG = np.array(df['RNG_price'].unique());
# RNG = RNG[::-1];
NG = np.array(df['NG_price'].unique());
fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(30,8),
                       gridspec_kw={
                           'width_ratios': [10,10,10,10],
                           'height_ratios': [10],
                       'wspace': 0.2,
                       'hspace': 0.2});
for c,cs in enumerate(costs):
    val = np.zeros((len(RNG),len(NG)));
    for i,r in enumerate(RNG):
        for j,g in enumerate(NG):
            s1=df[(df['NG_price']==g) & (df['RNG_price']==r)];
            val[i,j] = s1[cs];
    
    # ax[0].imshow(val,cmap='binary')
    # fig.colorbar(ax=ax[0])
    pcm = ax[c].pcolormesh(val,cmap='YlGnBu');
    cbar=fig.colorbar(pcm,ax=ax[c])
    # pcm.figure.axes[1].tick_params(axis='x',labelsize=15)
    
    
    ax[c].set_xticks(np.arange(len(NG))+1);
    s1 = [str(i2) for i2 in NG];
    ax[c].set_xticklabels(['2','3','5.45','7','10','15'],fontsize=15,fontweight='bold');
    ax[c].set_yticks(np.arange(len(RNG))+1);
    s1 = [str(i2) for i2 in RNG];
    ax[c].set_yticklabels(s1,fontsize=15,fontweight='bold');

    ax[c].set_title(lbs[c],fontsize=18,fontweight='bold')
    ax[c].set_xlabel('NG Price ($/MMBtu)',fontsize=23);
    ax[c].set_ylabel('LCDF Price ($/MMBtu)',fontsize=23);


name = 'RNG-NG-price-sensitivity.pdf';
fig.savefig(name,bbox_inches='tight');







